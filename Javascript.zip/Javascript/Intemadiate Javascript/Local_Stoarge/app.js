

let message = "Hello storage!";
localStorage.setItem("example", message);
console.log(localStorage.getItem('Example'))

let message1 = "Hii storage!";
localStorage.setItem("e", message);
console.log(localStorage.getItem('E'))


// window.localStorage.clear(); //Clear Ke liyye
// window.localStorage.removeItem("name"); // Position se remove krne k liye
// window.localStorage.getItem(window.localStorage.key(0));  // get k liye
// window.localStorage.key(0); // position pta krne k liyee


// Project :
// Shopping list item 
// Applcation
// List bane gi prompt k ya input  help se item add honge 
