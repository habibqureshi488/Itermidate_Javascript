// alert("hi i am zubair")
// console.log("Hi i am console")
// prompt("Hi i am prompt")
// let firstname = prompt("Enter your Name: ")
// let lastname = "shaikh"
//    let age = Math.floor(Math.random()*30);
// let age = prompt("Enter your age: ");
// console.log("My name is " , firstname , "and my age is" , age)
//    console.log("LastName:" , firstname)
// alert(a)
// console.log("value of a " , a)
// console.log(Math.floor(Math.random()*10))


// var full = 'zubair';
//  name = 2
//  {
// const age = 22;
// }
// console.log(age)

// Name =  "zubair"
// Name =  'zubair'
// Name =  `zubair`

// let favProgLang = prompt("Enter your fav prog lang")
// let message = `My fav prog language is ${favProgLang}` ;

// console.log(message)

// let str = "Hello, what's your name? Is it \"Mike\"?";
// console.log(str);
// let str2 = 'Hello, what\'s your name? Is it "Mike"?';
// console.log(str2);

// let bigNr = 90071992547409920n;
// let bigNr2 = 80071992547409920n;
// let age = 23;
// let plus = bigNr2 + bigNr

//  console.log(plus)


// console.log(name)

// let str1 = "JavaScript is fun!";
// let str2 = "JavaScript is fun!";
// console.log("These two strings are the same:", str1 ===  str2);

// let str1 = Symbol(23);
// let str2 = Symbol(23);

// console.log("These two strings are the same:", str1 ===  str2);
// let myName;
// let unassigned = undefined;
// let name1 = null
// console.log(typeof unassigned)
// console.log(typeof name1)
// console.log("These two strings are the same:", myName ===  unassigned);
// let age = 'value'
// let name = 'zubair';
// let age = 23;
// let married = false;
// let gender;
// let salary = null
// let saylaniSalary = 90071992547409920n
// let identity = Symbol('2345')

// let petName = prompt("enter your petname");

// let manName = prompt("enter your Name");


// console.log("pet name is equal to manName:" , petName === manName);
// console.log(typeof name)
// console.log(typeof age)
// console.log(typeof married)
// console.log(typeof gender)
// console.log(typeof saylaniSalary)
// console.log(typeof identity)
// console.log(typeof salary)

// let nr1 = -121;
// let nr2 = "2";
// let nr3 = "";

// console.log(typeof String(nr1))
// console.log(typeof Number(nr2))
// console.log(typeof Boolean(nr2))
// console.log(Boolean(nr1))
// console.log(Boolean(nr3))


// console.log(  Number(nr2)+String(nr1))



// let name = 'false';

// console.log(Boolean(name))

// let nr1 = 10;
// let nr2 = 3;
// let result1 = nr1 % nr2;
// console.log(`${nr1} % ${nr2} = ${result1}`);
// let nr3 = 8;
// let nr4 = 2;
// let result2 = nr3 % nr4;
// console.log(`${nr3} % ${nr4} = ${result2}`);
// let nr5 = 15;
// let nr6 = 4;
// let result3 = nr5 % nr6;
// console.log(`${nr5} % ${nr6} = ${result3}`);


// let num1 = 5;
// num1 = num1 + 1;
// num1++
// num1 = num1 - 1;
// num1--
// console.log(num1)

// let nr = 2;

// console.log("nr:" , nr)

// let newnumber = nr++
// let newnumber = ++nr

// console.log("newnumber" ,newnumber);
// console.log('nr:' , nr)






// console.log('nr:' , nr)
// let newVal1 = ++nr;



// console.log("newVal1" ,newVal1);

// console.log("nr:" , nr);

// let nr1 = 4;
// let nr2 = 5;
// let nr3 = 2;
// console.log(nr1++ + ++nr2 * nr3++);

// console.log(nr1)
// console.log(nr2)
// console.log(nr3)

// let a = prompt("Enter your value of A")
// let b = prompt("Enter your value of B")
// let plus = a**2 + b**2
// console.log(plus**0.5)

// let x = 2;
//     x **= 2
//     x -= 2
//     console.log(x)

// let a = 2;
// let b = 4;
// let c = 6;
// let d = 4;
// console.log(c%d)

//   a += b;
//   console.log(a)
//   a /= c;
//   console.log(a)
//    c %= b


//   console.log(a)
//   console.log(b)
//   console.log(c)

// let x = 5;
// let y = "5";
// console.log(x === y);

// let x = 5;
// let y = "5";
// console.log(x != y);


// let x = 6;
// let y = 6;

// console.log(y >= x); 
// console.log(y <= x); 

// let a = 1;
// let b = 2;
// let c = 3;
// let d = 4;


// console.log(a < b && b < c && c < d);

// console.log(a > b || b > c || d > c);

// let x = false;

// console.log(!x);
// console.log(x);

// let x = 1;
// let y = 2;
// console.log(!(x > y));

// let a = "Hello";
// a = prompt("world");
// console.log(a);


// let a = 5;
// let b = 70;
// let c = "5";
// b++;
// console.log(b);

// let result = 3 + 4 * 2 / 8;
// console.log(result)

// let firstNum = 5;
// let secondNum = 10;
// firstNum++;
// secondNum--;
// let total = ++firstNum + secondNum;
// console.log(total);
// let total2 = 500 + 100 / 5 + total--;
// console.log(total2);

// console.log(true ||false);

// let miles = prompt("enter your value is miles");
// let converter = Number(miles) * 1.60934;
// alert(`Your value in kilometer is ${converter}`)


// let rain = true;

// if(rain === true){
//    console.log("yes it's raining")
// }else{
//    console.log('no weather is clear')
// }
// let age = prompt("Enter your age:")

// if(Number(age) < 18) {
//    console.log("We're very sorry, but you can't get in under 18")
//   } else {
//    console.log("Welcome!");
//   }

// let hobby = "coding";

// if(hobby === "coding"){
//  console.log("** I love coding too! **");
// } else {
//  console.log("** Can you teach me that? **");
// }

// console.log(hobby === "coding" ? "** I love coding too! **" : "** Can you teach me that? **")


// let age = +prompt("Enter your Age");

// if(hobby === "coding"){
//  console.log("** I love coding too! **");
// } else {
//  console.log("** Can you teach me that? **");
// }

// console.log(age === 16 ? "yes 16" : age === 18 ? " yes it's 18" : age > 18 ? "yes it's greater than 18 " : "it's smaller" )



// let hobby = false;

// console.log(hobby)

// if(hobby = true){
//  console.log("** I love coding too! **");
// }
// if(!hobby){
//    console.log("** false statement");
// }

// let age = Number(prompt("Enter your age"));
// if (age < 18) {
//    console.log("you are not allowed");
// } else if (age === 18) {
//  console.log("only one year left to play wait for 1 year");
// }
// else{
// console.log('welcome!')
// }

// let age = Number(prompt("Enter your age"));
// let cost = 0;
// let message;
// if (age < 3) {
//  cost = 0;
//  message = "Access is free under three.";
// } else if (age >= 3 && age < 12) {
//  cost = 5;
//  message ="With the child discount, the fee is 5 dollars";
// } else if (age >= 12 && age < 65) {
//  cost = 10;
//  message ="A regular ticket costs 10 dollars.";
// } else {
//  cost = 7;
//  message ="A ticket is 7 dollars.";
// }
// console.log(message);
// console.log("Your Total cost "+cost);

// let activity = "Breakfast"

// if(activity === "Get up") {
//    console.log("It is 6:30AM");
//   } else if(activity === "Breakfast") {
//    console.log("It is 7:00AM");
//   } else if(activity === "Drive to work") {
//    console.log("It is 8:00AM");
//   } else if(activity === "Lunch") {
//    console.log("It is 12.00PM");
//   } else if(activity === "Drive home") {
//    console.log("It is 5:00PM")
//   } else if(activity === "Dinner") {
//    console.log("It is 6:30PM");
//   } 
// let age = 18;
// switch (true){
//    case (age > 19):
//     console.log("its greater ");
//     break;

//    case  (age === 18):


//    console.log("It is 18");
//    break
//    case (age < 16):
//    console.log("It is smaller");
//    break;
// }

// random number between 0 and 1
// let input = +prompt("enter your number")
// let randomNumber = Math.random();
// // multiply by 10 to obtain a number between 0 and 10
// randomNumber = randomNumber * 10;
// // removes digits past decimal place to provide a whole number
// let RandomNumber = Math.floor(randomNumber); 

// console.log(RandomNumber)


// switch(true) {
//    case input === RandomNumber:
//    console.log("congrats you win the prize");
//    break;
//    default:
//       console.log("sorry try again")
// }

// let activity = "zubair";

// switch(activity) {
//    case "Get up":
//    console.log("It is 6:30AM");
//    break;
//    case "Breakfast":
//    console.log("It is 7:00AM");
//    break;
//    case "Drive to work":
//    console.log("It is 8:00AM");
//    break;
//    case "Lunch":
//    console.log("It is 12:00PM");
//    break;
//    case "Drive home":
//    console.log("It is 5:00PM");
//    break;
//    case "Dinner":
//    console.log("It is 6:30PM");
//    break;
//    default:
//    console.log("I cannot determine the current time.");
//   }


// let student1Name = "zubair 22";
// let student1age = 22;
// let student1gender = "male";
// let student1Roll = 23234;
// let student1Class = "Matric";
// let student1Section = "Sec A";
// let student1Fee = 2222332323n;
// let student1Address = "adasdasd";


// let student1 = ["zubair" , 22 , "male" ,23234,"Matric" , "Sec A" , 2222332323n , "adasdasd" , true , undefined , null]

// let arr3 = new Array(10);
// let arr4 = [10];

// console.log(arr3)
// console.log(arr4)

// let arr = ["hi there", 5, true];

// console.log(typeof arr[0] , typeof arr[1])
// const name  = "zubair";
// name = "new name"
// console.log(name)
// const arr = ["hi there" , 22 , "zubair"];
// arr[0] = "new value";
// arr = ['zubair']
// arr[-1] = 'new number'

// console.log(arr[arr.length - 1]);

// let colors = ["black", "orange", "pink"]
// let booleans = [true, false, false, true];
// let emptyArray = [];
// console.log("Length of colors:", colors.length);
// console.log("Length of booleans:", booleans.length);
// console.log("Length of empty array:", emptyArray.length);

// let array = ["Milk" , "bread" , "apples"];
// console.log(array.length)

// array[1] = "banana";
// array.push("orange")
// console.log(array)
// array.splice(1,2,"orange" , "kiwi" , "pineapple")
// console.log(array)
// array.splice(2,0,"mango")
// let array1 = ["Milk" , 2 , "apples"];
// let array2 = ["orange" , true , "pineapple"];
// let mergeArray = array1.concat(array2)

// console.log(array1)
// console.log(array2)
// console.log(mergeArray)
// mergeArray.pop();
// console.log(mergeArray)
// mergeArray.splice(2,4)
// console.log(mergeArray)

// let array= ["Milk" , 2 , "apples"];
// array.shift();
// console.log(array)

// let array= ["Milk" , 2 , "apples"];
// array.unshift("zubair");
// console.log(array)

// let names = ["James", "Alicia", "Fatiha", "Maria", "Bert"];

// console.log(names);

// names.sort();

// console.log(names)

// let ages = [18, 72, 33, 56, 40];
// console.log(ages)

// ages.sort();

// console.log(ages)

// let names = ["James", "Alicia", "Fatiha", "Maria", "Bert"];

// console.log(names);
// names.reverse();

// console.log(names)


// let names = ["James", "Alicia", "Fatiha", "Maria", "Bert" ,'James' ];

// let findIndexOfJames = names.indexOf("James")
// let lastItem = names.indexOf("James")
// let lastItem = names.lastIndexOf("James")

// console.log(names)
// console.log(findIndexOfJames)
// console.log(lastItem)

// let someValues1 = [10, 20, 30];
// let arrOfArrays2 = [[1, 2, 3], [4, 5, 6], [7, 8, 9]];
// console.log(someValues1[1])

// let complexArray = [
//    [ [ 1, 2, 3 ], [ 4, 5, 6 ], [ 7, 8, 9 ] ],
//    [ [ 1, 2, 3 ], [ 4, 5, 6 ], [ 7, 8, 9 ] ],
//    [ [ 1, 2, 3 ], [ 4, 5, 6 ], [ 7, "zubair", 9 ] ]
//   ]

// console.log(complexArray[2][2][1])


let array = ["zubair", 23, false]
// console.log(array[0]);

let object = {
   name: "zubair",
   age: 23,
   married: false
}
// console.log(array)
// console.log(object)
// console.log("getting from array" , array[0]);

// console.log("getting from objet" , object["name"])
// console.log("getting from objet" , object.name)
// console.log("getting from objet" , object.age)
// console.log("getting from objet" , object.married)

let car = {
   model: 2023,
   brandName: "Volvo",
   color: "blue",
}

let myCarColor = "color"

car[myCarColor] = "yellow"

car.forSale = true;

console.log(car[myCarColor])

console.log(car)



//   object["name"] = "junaid";
//   console.log(object)

//   object.name = "jawad"

//   console.log(object)

let company = {
   companyName: "Healthy Candy",
   activity: "food manufacturing",
   address: {
      street: "2nd street",
      number: "123",
      zipcode: "33116",
      city: "Miami",
      state: "Florida"
   },
   yearOfEstablishment: 2021
};
console.log(company.address.number)