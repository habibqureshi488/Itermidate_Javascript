
// switch (userInput) {
//   case 1:
//   case 2:
//   case 4:
//   case 5:
//   case 6:
//   case 8:
//   case 9:
//     console.log("Better Luck Next Time");
//     break;
//   case 3:
//     console.log("Congratulations! You Win a Brand New Honda Bike");
//     break;
//   case 7:
//     console.log("Congratulations! You Win a Honda Civic Rs Turbo");
//     break;
//   case 10:
//     console.log("Congratulations! You Win a Sogo ka Generator Iron Juicer Blender");
//     break;
//   default:
//     console.log("Invalid input. Please enter a number between 1 and 10.");
//     break;
// }



// let randomNumber = Math.floor(Math.random() * 10) + 1;


// switch (randomNumber) {
//   case 1:
//   case 2:
//   case 4:
//   case 5:
//   case 6:
//   case 8:
//   case 9:
//     console.log("Better Luck Next Time");
//     break;
//   case 3:
//     console.log("Congratulations! You Win a Brand New Honda Bike");
//     break;
//   case 7:
//     console.log("Congratulations! You Win a Honda Civic Rs Turbo");
//     break;
//   case 10:
//     console.log("Congratulations! You Win a Sogo ka Generator Iron Juicer Blender");
//     break;
//   default:
//     console.log("I cannot determine the current time.");
//     break;
// }


// ********************* _____ ----------!!!`~`(((Chapter No 3)))`~`!!!---------- _____  *********************

// Advance Data type 
// 1. Object

// let student_Father_Name = "";
// let student_Class = "";
// let student_Address = "";
// let student_Email = "";
// let student_City = "";
// let student_Name = "";
// let student_School_Name = "";
// let student_PhoneNo = "";

// Arrays Practice at Home.......!




// let a = ["Milk" , "Bread" , "Apples"]
// let size = a.length;
// a[1]="Banana";
// console.log(a)

// let a = ["Milk" , "Bread" , "Apples"]
// a.splice(2,0,"orange");
// console.log(a)

// let a = ["Milk" , "Bread" , "Apples1" , "Apples"]
// a.splice(2,1,"orange");
// console.log(a)

// let a = ["Milk" , "Bread" , "Guava" , "Apples"]
// let size  = a.lenght;
// a.splice(2,0,"orange");
// a.splice(3,0,"Lehcee");
// a.splice(4,0,"Mango" ,"Kiwi" , "Peanut butter");
// console.log(a)


// array Mreginn

// let a = ["Milk" , "Bread" , "Oats"];
// let b = ["Orange" , "Bananas" , "Apples"];
// let c = a.concat(b);

// console.log(a)
// console.log(b)
// console.log(c)

// delete LAst Item in ARRay

// let a = ["Milk" , "Bread" , "Oats"];
// let b = ["Orange" , "Bananas" , "Apples"];
// let c = a.concat(b);

// console.log(a)
// console.log(b)
// console.log(c)
// c.pop();
// console.log(c);
// last console is important

// delete frist Item in ARRay

// let a = ["Milk" , "Bread" , "Oats"];
// let b = ["Orange" , "Bananas" , "Apples"];
// let c = a.concat(b);

// console.log(a)
// console.log(b)
// console.log(c)
// c.shift();
// console.log(c);

// add frist item in array 

// let a = ["Milk" , "Bread" , "Oats"];
// let b = ["Orange" , "Bananas" , "Apples"];
// let c = a.concat(b);

// console.log(a)
// console.log(b)
// console.log(c)
// c.unshift("Juice");
// console.log(c);


// line wise name calll in array (shorting Data)

// let a = ["Milk" , "Bread" , "Oats"];
// let b = ["Orange" , "Bananas" , "Apples"];
// let c = a.concat(b);
// console.log(c)
// c.sort();
// console.log(c)

// with number (shorting data)\

// let num =  [1,100,32,35,64,76,54,45,43,65,87,875,54,757,36,46,78,89]
// console.log(num);
// num.sort();
// console.log(num);

// line wise name calll in array (shorting Data) re-vers


// let a = ["Milk" , "Bread" , "Oats"];
// let b = ["Orange" , "Bananas" , "Apples"];
// let c = a.concat(b);
// console.log(c)
// c.reverse();
// console.log(c)


// practice

// let empty = []
// empty[0] = "Milk" 
// empty[1] = "Bread" 
// empty[2] = "Apple"
// empty.splice(1,0,"Banana","Eggs");
// empty.pop();
// // empty.short();
// empty.splice(2,0,"Carrot","Lettuce");
// let em = ["juices", "pop"]
// let final = empty.concat(em);
// final.pop();

// console.log(empty)
// console.log(em)
// final.sort();
// console.log(final)


// Index

// let num =  ["Orange" , "Bananas" , "Apples"]
// let index = num.indexOf(35)

// console.log(num)
// console.log(index)

// // Index last

// let num1 =  ["Orange" , "Bananas" , "Apples"]
// let index1 = num1.lastIndexOfindexOf(35)

// console.log(num1)
// console.log(index1)


// let company = {
//     companyName: "Healthy Candy",
//     activity: "food manufacturing",
//     address: {
//        street: "2nd street",
//        number: "123",
//        zipcode: "33116",
//        city: "Miami",
//        state: "Florida"
//     },
//     yearOfEstablishment: 2021
//  };
//  console.log(company.address.number)


// let company = {
//     companyName: "Healthy Candy",
//     activity: ["food manufacturing","food manufacturing","food manufacturing"],
//     address: {
//        street: "2nd street",
//        number: "123",
//        zipcode: "33116",
//        city: "Miami",
//        state: "Florida"
//     },
//     yearOfEstablishment: 2021
//  };
//  console.log(company.address.number)


// let company = { companyName: "Healthy Candy",
// activities: [ "food manufacturing",
// "improving kids' health",
// "manufacturing toys"],
// address: [{
// street: "2nd street",
// number: "123",
// zipcode: "33116",
// city: "Miami",
// state: "Florida"
// },
// {
// street: "1st West avenue",
// number: "5",
// zipcode: "75001",
// city: "Addison",
// state: "Texas"
// }],
// yearOfEstablishment: 2021
// };

// console.log(company.address[0].city);
// console.log(company.address[1].zipcode);
// console.log(company.address[1].city);


// End Chapter 3


// let people = {
//     friends: []
//   };
  
  
//   let  friend1 = {
//     firstName: "Murtaza",
//     lastName: "Hussain",
//     id: 1
//   };
  
//   let friend2 = {
//     firstName: "Umer",
//     lastName: "Farroq",
//     id: 2
//   };
  
//  let friend3 = {
//     firstName: "M",
//     lastName: "ALi",
//     id: 3
//   };
  
 
//   people.friends.push(friend1);
//   people.friends.push(friend2);
//   people.friends.push(friend3);
  
//   console.log(people.friends[1]);
//   console.log(people.friends[0]);
//   console.log(people.friends[2]);
//   console.log(people);
  
// const myArr1 = [1,3,5,6,8,9,15];
// console.log(myArr1.indexOf(0));
// console.log(myArr1.indexOf(3));


// const myArr2 = [];
// myArr2[10] = 'test'
// console.log(myArr2);
// console.log(myArr2[2]);

// const myArr3 = [3,6,8,9,3,55,553,434];
// myArr3.sort();
// myArr3.length = 0;
// console.log(myArr3[0]);

// Assiment 


// let myArray = ["John", "Doe", "Smith"];


// myArray.pop(); 
// myArray.shift(); 


// myArray.unshift("FIRST");


// myArray[2] = "MIDDLE";


// myArray[3] = "hello World";


// myArray.push("LAST");


// console.log(myArray);


// Create an array to hold the inventory of store items
// const theList = [];


// const item1 = {
//   name: 'Item 1',
//   model: 'Model A',
//   cost: 50,
//   quantity: 10
// };

// const item2 = {
//   name: 'Item 2',
//   model: 'Model B',
//   cost: 75,
//   quantity: 5
// };

// const item3 = {
//   name: 'Item 3',
//   model: 'Model C',
//   cost: 100,
//   quantity: 3
// };


// theList.push(item1, item2, item3);
// console.log(theList);
// console.log("Quantity of the third item:", theList[2].quantity);
// theList.push('Additional Data', { category: 'Electronics' });
// console.log("Additional data:", theList[3]);
// console.log("Object within the data structure:", theList[4]);



// Loops

// Reapeat All Things
// Smll Example
// let i =0;
// for(i ; i < 10 ; i++){
//     console.log("Hello World");
// }

// Increment
// let a = 0;

// for(a;a < 50 ;a++)
// {
//     console.log("Hello ` HABIB");
// }

// decrement

// let a = 100;

// for(a;a >0 ;a--)
// {
//     console.log("Hello ` HABIB");
// }


// let arr = [76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87,76,76,90,98,87,88,97,67,66,87]
// console.log(arr.length)

// let num = 0;

// for(num; num < 279 ; num++)
// {
//     if( arr[num] > 80)
//     {
//        console.log(`Student ${num} You are passed`)
//     }
//      else if( arr[num] < 80)
//     {
//        console.log(`Student ${num} You are Failed`)
//     }  
// }


// const myWork = [];


// for (let i = 1; i <= 10; i++) {
//   const status = i % 2 === 0 ? true : false; 
//   const lesson = {
//     name: `Lesson ${i}`,
//     status: status
//   };
//   myWork.push(lesson);
// }
// console.log(myWork);





// let arry = [];
// console.log(arry)

// for(let o=0; o<11; o++ )
// {
//     let find = o%2 === 0 ? true : false  
//     // console.log(o)
    
//     let obbj =
//     {
//         name:`lesson ${o}`,
//         Status: find  
//     }
//     arry.push(obbj)

// }
// console.log(arry)

  


// let arry = [];
// console.log(arry)

// for(let o=0; o<11; o++ )
// {
//     let find = o%2 
//     // console.log(o)
    
//     let obbj =
//     {
//         name:`lesson ${o}`,
//         Status: find === 0 ? true : false   
//     }
//     arry.push(obbj)

// }
// console.log(arry)
 
// Is code mein, ek empty array arry banaya gaya hai, jise phir console par print kiya gaya hai. Phir ek for loop chalaya gaya hai, jis mein o variable ko 0 se lekar 10 tak increment kiya jata hai.

// Har iteration mein, find variable mein o ka modulus 2 (o%2) store kiya jata hai. Modulus operation, ek number ko doosre number se divide karne par bachi hui remainder hasil karta hai. Is case mein, o ko 2 se divide karke, agar remainder 0 hota hai to find mein 0 aata hai, agar remainder 1 hota hai to find mein 1 aata hai.

// Phir, ek object obbj banaya jata hai, jiska name property "lesson" ke sath o ki value se initialize ki gayi hai aur Status property mein find ki value se initialize ki gayi hai. Agar find ki value 0 hai (yaani o even number hai), to Status true hoga, agar find ki value 1 hai (yaani o odd number hai), to Status false hoga.

// Is obbj object ko arry array mein push kiya jata hai, jis se har iteration mein ek naya object array mein add hota hai.

// Loop khatam hone ke baad, arry array ko phir se console par print kiya jata hai.

// Is code ki basic idea yeh hai ke ek array mein 0 se 10 tak ke lessons ki status (true ya false) ke sath objects create kiye jate hain. Jahan o even number hoga, wahan status true hoga, aur jahan o odd number hoga, wahan status false hoga.



// Nested LooopS\

// for(let i = 0 ; i<5; i++)
// {
//     console.log("I am I value",i)

//     for(let b = 0 ; b<3; b++)
//     console.log("I am B value",b)
// }


// while loop


// let num = 0;
// while(num < 10)
// {
//     console.log("Hello" , num)
//     num++;
// }




// var min_value = 1;  
// var max_value = 100;

// var random_number = Math.floor(Math.random() * (max_value - min_value + 1));
// console.log("Random Number:", random_number);
// let user = (prompt("Enter yor Number"))
// if(random_number == user )
// {
//     console.log("Right")

// }

// else
// {
//     console.log("Wrong")
// }




// let num = 0;
// let somarry = ["name1","name2","name3","name4","name5","name6"]
// while(num < 6)
// {
//     if(somarry[0] === "name4")
//     {
//         console.log("Found Her!!!")
//         console.log(somarry)
        
//     }
//     else
//     {
//         somarry.shift();
//     }
// num++;
// }


// var max_value = 50;

// var random_number = Math.floor(Math.random() * (max_value  ,+ 1));
// console.log("Random Number:", random_number);

// let defult = true;

// while(defult)
// {
//     user = (prompt("Enter Your Number", + max_value))
//     user = Number (user);

//      if(user === random_number)
//      {
//         defult = false;
//         console.log("You GOt IT")
//      }
//      else if(user > random_number)
//      {
//         console.log("High")
//      }
//      else
//      {
//         console.log("Low")
//      }

// // }




//********************************************* */ dooo while looop********************************




// let number;

// do {
// number = prompt("Please enter a number between 0 and 100: ");
// } while (!(number >= 0 && number < 100));
// console.log(number)



// let arry = []
// for(let i = 0; i<10; i++)
// {
//   arry.push = "a";
//   console.log(arry)
//   for(let name of arry)
//   {
//     console.log(name)
//   }

// }



// const myArray = [];

// for (let i = 1; i <= 10; i++) {
//   myArray.push(i);
// }

// console.log(myArray);

// for (let j = 0; j < myArray.length; j++) {
//   console.log(`Value at index ${j}: ${myArray[j]}`);
// }
// for (const value of myArray) {
//   console.log(`Value: ${value}`);
// }



// let car = {
//     model: "Golf",
//     make: "Volkswagen",
//     year: 1999,
//     color: "black",
//     };

    
//     for (let prop in car){
//         console.log(prop);
      
//     console.log(car[prop]);
//     }



    // let obj =
    // {
    //     name : "abc",
    //     class : 6,
    //     subject : "Science"

    // }

    // for (let i in obj)
    // {
    //     console.log(i);
    //     console.log(obj[i]);
    // }

    // let arry = []
    
    // arry.push = obj;
    // console.log(arry)


    // let car = {
    //         model: "Golf",
    //         make: "Volkswagen",
    //         year: 1999,
    //         color: "black",
    //         };

    //         let arrkey = Object.keys(car)
    //         let arrv = Object.values(car)
    //         console.log(arrkey)
    //         console.log(arrv)

    //         for( let i of arrkey)
    //         {
    //             console.log(i)
    //         }
    //         for( let h of arrv)
    //         {
    //             console.log(h)
    //         }


    // let car = {
    //     model: "Golf",
    //     make: "Volkswagen",
    //     year: 1999,
    //     color: "black",
    //     };

    //     let arry = Object.entries(car)
    //     for(let [key , value] of arry)
    //     {
    //         console.log(key, ":", value);
    //     }

// for ( let i = 0; i < 10 ; i++)   
// {
//     console.log(i)
//     if(i === 4)
//     {
//         break;
//     }
// }     

let cars = [
    {
    model: "Golf",
    make: "Volkswagen",
    year: 1999,
    color: "black",
    },
    {
    model: "Picanto",
    make: "Kia",
    year: 2020,
    color: "red",
    },
    {
    model: "Peugeot",
    make: "208",
    year: 2021,
    color: "black",
    },
    {
    model: "Fiat",
    make: "Punto",
    year: 2020,
    color: "black",
    }
    ];

    for (let i = 0; i < cars.length; i++) {
        if (cars[i].year >= 2020) {
        if (cars[i].color === "black") {
        console.log("I have found my new car:", cars[i]);
        break;
        }
        }
        }



// Function






















// Practice 6.1

// function fun (a,b)
// {
//    return a;  
// }

// a = fun(5+15)

// console.log("Result is ", a)


// Practice 6.2

// let arry = ["a","b", "c", "d"]

// function called()
// {
//     let a = (prompt("Enter Your Name"))
//     var random_number = Math.floor(Math.random() * arry.length);

//     console.log( a ,arry[random_number])
   

// }

// called()



        //Function Day 2

        // let addTwoNumbers = (x, y) => console.log(x + y);
        // addTwoNumbers(5, 3);
        // let sayHi = () => console.log("hi");


        // Practice 6.4

        // let arry = ["Hi","Hello", "Byeee", "OK"]

        // function called()
        // {
        //     let a = (prompt("Enter Your Name"))
        //     var random_number = Math.floor(Math.random() * arry.length);
        
        //     return ( a ,arry[random_number])
           
        // }




//  const arry =[];
//         for (let i = 0; i < 10; i++)
//         {      
           
//             const firstValue = i * 5;
//             const secondValue = i * i;
//               function add(x , y)
//            {                           
//               return x + y;
//            }
//           const h = add(firstValue,secondValue);
//           arry.push(h);
//         }
       
//         console.log(arry);
        


// const resultArray = [];
// for (let i = 0; i < 10; i++) {
//  const firstValue = i * 5;
// const secondValue = i * i;
// function addValues(a, b) {
//     return a + b;
//   }
// const response = addValues(firstValue, secondValue);
//  resultArray.push(response);
// }


// console.log(resultArray);



// const arr = []

// let var1 = (prompt("Enter Your Name"))
// let var2 = (prompt("Enter Your Gender"))
// let var3 = (prompt("Enter Your Class"))

// for (let i = 0; 1<10; i++)
// {
//     obj = func()
//     {
//         "Name" : var1,
//          "Gender" : var2,
//          "Class" : var3,
//     }
// }


function func(abc) 
{
  console.log(abc)
    if (abc === 0) {
        return 1;
        
    }
    else{
      return abc * func(--abc)
    }

      
}


// func(5)
console.log(func(5))


// function factorial(n) {
//     if (n === 0) {
//       return 1;
//     } else {
//       console.log(`Calculating factorial of ${n}`);
//       const result = n * factorial(n - 1);
//       console.log(`Factorial of ${n} is ${result}`);
//       return result;
//     }
//   }
  
//   const numberToFindFactorialOf = 5;
//   const result = factorial(numberToFindFactorialOf);
//   console.log(`The factorial of ${numberToFindFactorialOf} is ${result}`);
  

function doOuterFunctionStuff(nr) {
    console.log("Outer function");
    doInnerFunctionStuff(nr);
    function doInnerFunctionStuff(x) {
    console.log(x + 7);
    console.log("I can access outer variables:", nr);
    }
    }
    doOuterFunctionStuff(7);

// Practice 6.7
//     1. Set the start variable at a value of 10 , which will be used as the
// starting value for the loop.
// 2. Create a function that takes one argument, which is the countdown
// value.
// 3. Within the function, output the current value of the countdown into the
// console.
// 4. Add a condition to check if the value is less than 1; if it is, then return
// the function.
// 5. Add a condition to check if the value of the countdown is not less than
// 1, then continue to loop by calling the function within itself.
// 6. Make sure you add a decrement operator on the countdown so the
// preceding condition eventually will be true to end the loop. Every time
// it loops, the value will decrease until it reaches 0.
// 7. Update and create a second countdown using a condition if the value is
// greater than 0. If it is, decrease the value of the countdown by 1.
// 8. Use return to return the function, which then invokes it again and
// again until the condition is no longer true.



// Anonymous Fucnction

// let Anonymous = function()
// {
//     console.log("Anonymous")
// }


// // Callback Functions


// function funcction(params) 

// {
//     params();
//     console.log("Inside Prams Function");
    
// }
// funcction(Anonymous);


// let curnttime = new Date();
// console.log(curnttime);

// let curne = new Date.now();
// console.log(curne);


// let d = new Date();
// console.log("Day of week:", d.getDay());
// console.log("Day of month:", d.getDate());
// console.log("Month:", d.getMonth());
// console.log("Year:", d.getFullYear());
// console.log("Seconds:", d.getSeconds());
// console.log("Milliseconds:", d.getMilliseconds());
// console.log("Time:", d.getTime());

// let dy = new Date();
// console.log("Day of 2:" , dy.getDate());  //time day date month year time second millisecond nanosecond function....
// console.log("Day of 3:" , dy.getDay());  //time day date month year time second millisecond nanosecond function....
// console.log("Day of 4:" , dy.getFullYear());  //time day date month year time second millisecond nanosecond function....
// console.log("Day of 5:" , dy.getHours());  //time day date month year time second millisecond nanosecond function....
// console.log("Day of 6:" , dy.getMilliseconds());  //time day date month year time second millisecond nanosecond function....
// console.log("Day of 7:" , dy.getMinutes());  //time day date month year time second millisecond nanosecond function....
// console.log("Day of 8:" , dy.getMonth());  //time day date month year time second millisecond nanosecond function....
// console.log("Day of 9:" , dy.getSeconds());  //time day date month year time second millisecond nanosecond function....
// console.log("Day of 10:" , dy.getTime());  //time day date month year time second millisecond nanosecond function.
// console.log("Day of 11:" , dy.getTimezoneOffset()); //time day date month year time second millisecond nanosecond function.
// console.log("Day of 12:" , dy.getUTCDate()); //time day date month year time second millisecond nanosecond function.
// console.log("Day of 13:" , dy.getUTCDay()); //time day date month year time second millisecond nanosecond function.
// console.log("Day of 14:" , dy.getUTCMilliseconds()); //time day date month year time second millisecond nanosecond function.
// console.log("Day of 15:" , dy.toLocaleDateString()); //time day date month year time second millisecond nanosecond function.
// console.log("Day of 16:" , dy.getUTCHours()); //time day date month year time second millisecond nanosecond function.
// console.log("Day of 17:" , dy.toLocaleDateString()); //time day date month year time second millisecond nanosecond function.


// Excersice 8.7

 let curnttime = new Date();
let arry = ["Jun","Feb","Mar","Aprl","May","Jne","July","Aug","Sep","Oct","Nov","Dec"]
 let a = curnttime.getDate();
 let b = curnttime.getFullYear();
 let c = curnttime.getMonth();
//  a.concat(arry[9]);
// console.log(arry);
 
let result = [`${a}, ${c}, ${b}`];
console.log(result);

// Split biultin func method..
//Join biultin func method..

// Chapter 8
// number method  , is name method , infinite method , String Method.
// to fix ka method

let x = 1.23456;
let newX = x.toFixed(2);
console.log(x, newX);

// hightest number pta krne k liyee  Math.max  ka method
// lowest number  pta krne k liyee   Math.min  ka method
// Squre root nikal na ke liyee      Math.sqrt ka method 


// let x = 1.23456;
// let newX = x.toPrecision(2);

// let x = 1.23456;
// let newX = x.toPrecision(4);
// console.log(newX);

// let highest = Math.max(2, 56, 12, 1, 233, 4);
// console.log(highest);

// let lowest = Math.min(2, 56, 12, 1, 233, 4);
// console.log(lowest);

// let highestOfWords = Math.max("hi", 3, "bye");
// console.log(highestOfWords);

// let result = Math.sqrt(64);
// console.log(result);

// let result2 = Math.pow(5, 3);
// console.log(result2);

// round krne k liyee

// let x = 6.78;
// let y = 5.34;
// console.log("X:", x, "becomes", Math.round(x));
// console.log("Y:", y, "becomes", Math.round(y));


//****************************************************************************************************** */

// Power niklne ka method Math.Pow(number jis ki power nikalni ho) jese 5 ki power 3  (5, 3)
// Math.ceil  type of round method incerase or decrease..
// Math .Floor type of round method incerase or decrease..


// Methods :  .replace .floor .random 

// Exponent OR logarithm

// math.exp() Exponent  niklne k liyee.
// math.log() logarithm niklne k liyee.


// *************************************************************************************************************************************************************************************************************************************************************************************************************************************************************
//*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************
//*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************
//*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************


// Practice exercise 8.6
// Experiment with the Math object with these steps:
// 1. Output the value of PI into the console using Math .
// 2. Using Math get the ceil() value of 5.7 , get the floor() value of
// 5.7 , get the round value of 5.7 , and output it into the console.
// 3. Output a random value into the console.
// 4. Use Math.floor() and Math.random() to get a number from 0 to 10.
// 5. Use Math.floor() and Math.random() to get a number from 1 to 10.
// 6. Use Math.floor() and Math.random() to get a number from 1 to 100.
// 7. Create a function to generate a random number using the parameters of
// min and max . Run that function 100 times, returning into the console
// a random number from 1 to 100 each time.




// let PI = math.PI(1);
// console.log(PI);

// let m = 56.6756755 
// m = math.ceil()
// m = math.floor()
// m = math.round()
// console.log(m)

// let num = 5.7
// console.log("Ceil" , num , ":" , Math.ceil(num))
// console.log("Floor" , num , ":" , Math.floor(num))
// console.log("Round" , num , ":" , Math.round(num))


// let random = Math.random()
// console.log(Math.floor(random * 10))
// console.log(Math.floor(random * 10 + 1))
// console.log(Math.floor(random * 10 + 1))


// function func(max ,min)
// {
//  return Math.floor(Math.random() * (max - min + 1)) + min;
// }

// for (let index = 0; index <= 100; index++) 
//  {
//     console.log(func(1,100))
    
//  }

//  let num = 5.7
// console.log("Ceil" , num , ":" , Math.ceil(num))
// console.log("Floor" , num , ":" , Math.floor(num))
// console.log("Round" , num , ":" , Math.round(num))


// let random = Math.random()
// console.log(Math.floor(random * 10))
// console.log(Math.floor(random * 10 + 1))
// console.log(Math.floor(random * 10 + 1))


// function func(max ,min)
// {
//  return Math.floor(Math.random() * (max - min + 1)) + min;
// }

// for (let index = 0; index <= 100; index++) 
//  {
//     console.log(func(1,100))
    
//  }


//  Array MEthod
// ForEach ka method
// 

// let ar = ["grapefruit", 4, "hello", 5.6, true]

// example 1


// function printStuff(element, index) {
// console.log("Printing stuff:", element, "on array position:", index)
// }
// ar.forEach(printStuff);


// example 2

// ar.forEach((parm , ind) => {
//     console.log("Printing stuff:", parm, "on array position:" , ind);
// })



// let arr = [2,3,32,4,5, new Date(), true];
// function checkString(element, index) {
// return typeof element === "string";
// }
// let filterArr = arr.filter(checkString);
// console.log(filterArr);

// let arr = ["squirrel", 5, "Tjed", new Date(), true];
// function checkString(element, index) {
// return typeof element === "string";
// }
// let filterArr = arr.filter(checkString);
// console.log(filterArr);


// let arr = ["squirrel", 5, "Tjed", new Date(), true];
// function checkString(element, index) {
// return typeof element === "string";
// }

// // let filterArr = arr.filter(checkString);
// // console.log(filterArr);

// arr.forEach((a , b) => {
 
    

// })


// find number

// let rr = ["squirrel", 5, "Tjed", new Date(), true];
// function checkString(element, index) {
// if (typeof element === "string" || typeof element === "number") {
    
    
// }
// }
// let filterArr = rr.filter(checkString);
// console.log(filterArr);


// let arr1 = [1, 2, 3, 4];
// let mapped_arr = arr1.map(x => x + 1);
// console.log(mapped_arr);

// let arr2 = [1, 2, 3, 4];
// let mapped = arr2.map(a => a+ 1);
// console.log(mapped);


// Original array
// const numbers = [1, 2, 3, 4, 5];

// // Use the map() method to double each number in the array
// const doubledNumbers = numbers.map(function(number) {
//   return number * 2;
// });

// // The original 'numbers' array remains unchanged, and 'doubledNumbers' contains the updated values
// console.log(numbers);         // Output: [1, 2, 3, 4, 5]
// console.log(doubledNumbers);  // Output: [2, 4, 6, 8, 10]


// let point = ["Asad" , "Ayaz" , "Ali" , "Asad" , "Ayan" , "Ali"]
// const filter = point.filter((value,index,array) => {
// console.log(value,index,array.indexOf(value));
// return point.indexOf(value) === index;

// });

// console.log(filter)



// DOM Chapter 9 DOM Data Object Model 

// const ele1 = document.querySelector("h1");
// console.dir(ele1);

// const ele1 = document.querySelectorAll("h1");
// console.dir(ele1);

// Chapter 10 Dynamic Element Manipulation
// Using the DOM


// const ele1 = document.querySelectorAll("h1");
// const els2 =  document.body.children.greeting.innerText = ("Bye");
// console.dir(ele1)
// console.dir(els2)



// const i = document.getElementById.innerHTML = ("abcodsnl"); 
// console.dir(i);


// const i = document.getElementsByTagName.innerHTML = ("h1"); 
// console.dir(i);


// const i = document.getElementsByClassName("e"); 
// console.dir(i);

// const i = document.getElementById("g"); 
// console.dir(i);

// const p = document.getElementById("r"); 
// const q = document.getElementById("i"); 
// const s = document.getElementById("d"); 
// const i = document.getElementById.innerHTML = ("result"); 
// const j = document.getElementById.innerHTML = ("informATION"); 
// const k = document.getElementById.innerHTML = ("dANGER"); 
// console.dir(p);
// console.dir(q);
// console.dir(s);
// console.dir(i);
// console.dir(j);
// console.dir(k);

// const w = document.querySelectorAll(".a");
// console.dir(w);

// function l ()
// {
//     alert('NIce');
// }


// ***********************Calculator**************************
let currentDisplay = "";

function appendToDisplay(value) {
  currentDisplay += value;
  document.getElementById("display").value = currentDisplay;
}

function clearDisplay() {
  currentDisplay = "";
  document.getElementById("display").value = "0";
}

function calculateResult() {
  
    currentDisplay = eval(currentDisplay);
    document.getElementById("display").value = currentDisplay;
 
}

// ***********************Calculator**************************

// Element Click Handler

// function oclck(el) {
// //    document.getElementById(el.i)
// console.log(el)
//     console.log(el.InnerText)
// }
// function clr() {

    
// }

function lssop() {
    let lop = document.getElementsByTagName("div");
    // console.log(lop)
    for (let i = 0; i < lop.length; i++) {
        div[i].style.backgroundColor = lop[i].id;
        
    }
}

// Manipulating attributes




// Event Listener Compeleted






















// IOT means INTERNET OF THINGS